document.addEventListener('DOMContentLoaded', function() {
  console.log('Project rifa.html is ready!');
});